package com.project1.FinalProject1.service;

import org.springframework.security.core.userdetails.UserDetailsService;

import com.project1.FinalProject1.model.User;
import com.project1.FinalProject1.web.dto.UserRegistrationDto;

public interface UserService  extends UserDetailsService{
	User save(UserRegistrationDto registrationDto);
}
